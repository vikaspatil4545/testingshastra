package com.userexception;

public class UserDefinedexception extends Exception{
	
	public void elementNotInteractableException() throws UserDefinedexception,ArithmeticException
	{
		//try {
			
			throw new UserDefinedexception();
			
		//} catch (Exception e) {
			//System.err.println("element not found exception");
			
		//} 
		
	}
	
	

}
