package com.keywords;

import java.io.FileInputStream;
import java.util.Properties;
//import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Constants {
	//private static Logger log = Logger.getLogger(Constants.class);
	public static WebDriver driver;
	public static FileInputStream fis;
	public static Properties prop;
	public static WebElement webelement;
	public static int count=0;
	

}
