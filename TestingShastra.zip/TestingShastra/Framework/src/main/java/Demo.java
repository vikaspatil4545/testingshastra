
import org.testng.annotations.Test;

public class Demo {
	@Test
	void run() throws InterruptedException {
		System.out.println("hello");

	}

}
