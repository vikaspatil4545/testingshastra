package com.utility;

public class Locator {
	private static  String logoImage1;
	private static  String logoImage2;
	private static  String logoImage3;
	private static  String logoImage4;
	private static  String logoImage5;
	private static  String logoImage6;
	private static  String logoImage7;
	private static  String logoImage8;
	private static  String logoImage9;
	
	public static String getLogoImage1() {
		return logoImage1;
	}
	public static void setLogoImage1(String logoImage1) {
		Locator.logoImage1 = logoImage1;
	}
	public static String getLogoImage2() {
		return logoImage2;
	}
	public static void setLogoImage2(String logoImage2) {
		Locator.logoImage2 = logoImage2;
	}
	public static String getLogoImage3() {
		return logoImage3;
	}
	public static void setLogoImage3(String logoImage3) {
		Locator.logoImage3 = logoImage3;
	}
	public static String getLogoImage4() {
		return logoImage4;
	}
	public static void setLogoImage4(String logoImage4) {
		Locator.logoImage4 = logoImage4;
	}
	public static String getLogoImage5() {
		return logoImage5;
	}
	public static void setLogoImage5(String logoImage5) {
		Locator.logoImage5 = logoImage5;
	}
	public static String getLogoImage6() {
		return logoImage6;
	}
	public static void setLogoImage6(String logoImage6) {
		Locator.logoImage6 = logoImage6;
	}
	public static String getLogoImage7() {
		return logoImage7;
	}
	public static void setLogoImage7(String logoImage7) {
		Locator.logoImage7 = logoImage7;
	}
	public static String getLogoImage8() {
		return logoImage8;
	}
	public static void setLogoImage8(String logoImage8) {
		Locator.logoImage8 = logoImage8;
	}
	public static String getLogoImage9() {
		return logoImage9;
	}
	public static void setLogoImage9(String logoImage9) {
		Locator.logoImage9 = logoImage9;
	}
	public static String getLogoImage()
	{
		return logoImage1;
		
	}
	public  void setLogoImage(String logoImage1) {
		Locator.logoImage1 = logoImage1;
	}

}
