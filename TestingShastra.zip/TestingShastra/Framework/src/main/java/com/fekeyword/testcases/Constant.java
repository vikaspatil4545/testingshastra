package com.fekeyword.testcases;

import java.io.FileInputStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public  class Constant {
	public static WebElement element;
	public static WebDriver driver;
	public static String text;
	public static String webeletxt;
	public static int count;
	public static FluentWait<Wait> wait;
	public static FileInputStream fis;
	
	 public static void main(String a[]) {
		try
		{
			int num=10/0;
		}
		
        
         catch (Exception e) {
			
		}
		 

	}

}
