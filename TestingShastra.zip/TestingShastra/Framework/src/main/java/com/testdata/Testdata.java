package com.testdata;

import org.testng.annotations.Test;

import com.newkeyword.KeywordFE;


public class Testdata extends KeywordFE {
	//https://reg.ebay.com/reg/PartialReg?siteid=0&co_partnerId=0&UsingSSL=1&rv4=1&ru=https%3A%2F%2Fwww.ebay.com%2Fn%2Ferror%3Fstatuscode%3D500&signInUrl=https%3A%2F%2Fwww.ebay.com%2Fsignin%3Fsgn%3Dreg%26siteid%3D0%26co_partnerId%3D0%26UsingSSL%3D1%26rv4%3D1%26ru%3Dhttps%253A%252F%252Fwww.ebay.com%252Fn%252Ferror%253Fstatuscode%253D500
  @Test
	public void datatesting() {
		KeywordFE.openBrowser("Chrome");
		KeywordFE.maximizeBrowser();
		KeywordFE.openUrl("https://reg.ebay.com/reg/PartialReg?siteid=0&co_partnerId=0&UsingSSL=1&rv4=1&ru=https%3A%2F%2Fwww.ebay.com%2Fn%2Ferror%3Fstatuscode%3D500&signInUrl=https%3A%2F%2Fwww.ebay.com%2Fsignin%3Fsgn%3Dreg%26siteid%3D0%26co_partnerId%3D0%26UsingSSL%3D1%26rv4%3D1%26ru%3Dhttps%253A%252F%252Fwww.ebay.com%252Fn%252Ferror%253Fstatuscode%253D500");
	}
}
