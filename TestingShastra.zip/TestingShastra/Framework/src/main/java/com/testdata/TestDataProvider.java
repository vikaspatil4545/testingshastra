package com.testdata;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fekeyword.testcases.Constant;
import com.newkeyword.KeywordFE;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestDataProvider  {
	WebDriver driver;
	@BeforeTest
	public  void openBrowser() {
		
		WebDriverManager.chromedriver().setup();
		RemoteWebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
		driver.findElement(By.cssSelector("[class=\"_2AkmmA _29YdH8\"]")).click();
		driver.findElement(By.cssSelector("[class=\"_3Ep39l\"]")).click();
		
	}
	
	
	@Test(dataProvider = "Testdata")
	public void m1( String email, String password) throws IOException, InterruptedException {
		
		/*WebDriverManager.chromedriver().setup();
		RemoteWebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
		System.out.println("Chrome browser is open");
		
		driver.findElement(By.cssSelector("[class=\"_2AkmmA _29YdH8\"]")).click();
		driver.findElement(By.cssSelector("[class=\"_3Ep39l\"]")).click();
		System.out.println("it click on login button");
		*/
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("[class=\"_2zrpKA _1dBPDZ\"]")).clear();
		driver.findElement(By.cssSelector("[class=\"_2zrpKA _1dBPDZ\"]")).sendKeys(email);
		
		driver.findElement(By.cssSelector("[class=\"_2zrpKA _3v41xv _1dBPDZ\"]")).clear();
		driver.findElement(By.cssSelector("[class=\"_2zrpKA _3v41xv _1dBPDZ\"]")).sendKeys(password);
		
		
		//driver.close();
	  //System.out.println(email + "\t" + password );
		 
	}
	
	
	/*@AfterTest
	public void closeBrowser() {
		driver.close();

	}*/
	
	@DataProvider(name = "Testdata")
	public static Object[][] regData() {
		
		Object[][] values=null;
		try {
			Constant.fis=new FileInputStream("D:\\empdata.xlsx");
			
			XSSFWorkbook book = new XSSFWorkbook(Constant.fis);
			XSSFSheet sheet = book.getSheet("Sheet5");
			//sheet=book.createSheet("newsheet");
			
			int rows = sheet.getLastRowNum();
			Row r = sheet.getRow(0);
			values = new Object[rows][r.getLastCellNum()];
			for (int i = 1; i <= rows; i++) {
				Row row = sheet.getRow(i);
				int cells = row.getLastCellNum();
				for (int j = 0; j < cells; j++) {
					Cell cell = row.getCell(j);
					switch (cell.getCellType()) {
					case NUMERIC:
						values[i - 1][j] = cell.getNumericCellValue();
						break;
					case STRING:
						values[i - 1][j] = cell.getStringCellValue();
						break;
					case BLANK:
						values[i-1][j]="";
						break;
					case FORMULA:
						values[i - 1][j] = cell.getCellFormula();
						break;
					case BOOLEAN:
						values[i - 1][j] = cell.getBooleanCellValue();
						break;
						
					default:
						System.out.println("Invalid  value found in cell");
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("file is not present at the location");
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		return values;
		

	}

}
