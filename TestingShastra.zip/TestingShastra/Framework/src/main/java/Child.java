
class Parent {
	public void displayMsg() {
		System.out.println("I am parent method");

	}
}

class Child extends Parent {

	public static  void childmethod() {
		System.out.println("I am child method");

	}

	public static void main(String a[]) {
		Parent p = new Child();
		Parent p1=new Parent();
		Child c = new Child();
		c.childmethod();
		p.displayMsg();
		Child.childmethod();
		//p1.childmethod();

	}
}
