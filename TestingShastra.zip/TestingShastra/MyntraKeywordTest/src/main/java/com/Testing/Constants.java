package com.Testing;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class Constants {
	public static WebDriver driver;
	public static Properties prop;
	public static FileInputStream fis;
	public static Actions action;


}
