package com.firstmaven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import bsh.commands.dir;
import io.github.bonigarcia.wdm.WebDriverManager;

public class FacebookTestcase {
	RemoteWebDriver driver;
	// HtmlUnitDriver driver;
	String mob = "9921194982", Password = "Vikasc", matching="Enter Security Code";

	@BeforeTest
	public void openBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// driver=new HtmlUnitDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/");
		
		System.out.println("browser opened successfully");
	}

	/**
	 * Entering Information in the text
	 */
	/*@Test(priority = 1)
	public void tc_01() {
		driver.findElement(By.xpath("//input[@name=\"firstname\"]")).sendKeys("Vikas");
		driver.findElement(By.xpath("//input[@name=\"lastname\"]")).sendKeys("Chorghade");
		driver.findElement(By.xpath("//input[@name=\"reg_email__\"]")).sendKeys(mob);
		driver.findElement(By.xpath("//input[@name=\"reg_passwd__\"]")).sendKeys("Vikas12345");
		Assert.assertEquals("Vikas", "Vikas");

	}

	/**
	 * To Verify date is select according to birth date 
	 */
/*	@Test(priority = 2)
	public void tc_02() throws InterruptedException {
		WebElement day = driver.findElement(By.xpath("//select[@name=\"birthday_day\"]"));
		Select selectday = new Select(day);
		selectday.selectByVisibleText("2");
		WebElement month = driver.findElement(By.xpath("//select[@name=\"birthday_month\"]"));
		Select selectmonth = new Select(month);
		selectmonth.selectByValue("12");
		WebElement year = driver.findElement(By.xpath("//select[@name=\"birthday_year\"]"));
		Select selectyear = new Select(year);
		selectyear.selectByValue("1993");
		Assert.assertEquals(2, 2);
	}*/

	/**
	 * This method is going to check the mobile number.
	 */
	/*@Test(priority = 3)
	public void tc_03() {
		if (mob.equals(mob)) {
			System.out.println("Allready has an account with this mobile number then login with mobile no");
		} else {
			System.out.println("Enter email another mobile number or email address");
		}
		Assert.assertEquals(mob, mob);

	}*/

	/**
	 * Method tc_04 is used for the login process.
	 */
/*	@Test(priority = 4)
	public void tc_04() {
		System.out.println("Entering Login credencials");
		driver.findElement(By.xpath("//input[@name=\"email\"]")).sendKeys("9921194982");
		driver.findElement(By.xpath("//input[@name=\"pass\"]")).sendKeys(Password);
		System.out.println("checking password");
		if (Password.equals("Vikasc")) {
			driver.findElement(By.xpath("//input[@value=\"Log In\"]")).click();
			System.out.println("Password is correct");
		}

		else {
			driver.findElement(By.xpath("//div/a[contains(text(),\"Forgotten\")]")).click();
			driver.findElement(By.xpath("//input[@placeholder=\"Mobile number\"]")).sendKeys("9921194982");

		}
		Assert.assertEquals(Password, "Vikasc");

	}*/

	/**
	 * To verify Login is Successfully done.
	 */
	/*@Test(priority = 5)
	public void tc_05() throws InterruptedException {
		WebElement name = driver.findElement(By.xpath("//div[contains(text(),'Vikas')]"));
		System.out.println(name.getText());
		Assert.assertEquals(name.getText(), "Vikas Chorghade");

	}*/
	@Test
	public void tc_06() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(text(),\"Forgotten\")]")).click();
		driver.findElement(By.xpath("//input[@id=\"identify_email\"]")).sendKeys("9921194982");
		driver.findElement(By.xpath("//input[@value=\"Search\"]")).click();
		driver.findElement(By.xpath("//ul/li[1]/div/table/tbody/tr/td/a")).click();
		driver.findElement(By.xpath("//div/button[@value=\"1\"]")).click();
		WebElement code=driver.findElement(By.xpath("//div[@class=\"clearfix uiHeaderTop\"]/div[1]/h2"));
		System.out.println(code.getText());
		Assert.assertEquals(code, matching);

	}

}