package com.firstmaven.counstomeUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ProperitesUtils {
	static Properties  pro=new Properties();
	public static String  getLocators( String locatorname) {
		String value="";
		try {
			String basepath=System.getProperty("user.dir");
			System.out.println("Absolutepath"+basepath);
			FileInputStream fis =new FileInputStream(basepath+"/FirstProject/src/test/resources/ObjectRepository.properties");
			pro.load(fis);
			value=(String) pro.getProperty(locatorname);
		} catch (FileNotFoundException e) {
			System.err.println("Object Repository not found");
			e.printStackTrace();
		} catch (IOException e) {
		System.err.println(" unable to load properites files");
			e.printStackTrace();
		}
		
		return value;

	}
	


}
