package com.firstmaven;

import static org.testng.Assert.assertEquals;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TataSkyDTHmanage {
	WebDriver driver;
	String Title = "Best DTH(Direct To Home) Service Provider in India | Tata Sky", OTP = "Select Debit Card Option :",
			Statusofacc = "Sorry! The Subscriber Id you have entered is not Active";
		int total = 8;

	@BeforeTest
	public void launchbrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.tatasky.com/wps/portal");
		System.out.println("Browser opened successfully");
	}

	@Test(priority = 0)
	public void TC_01() {
		String LoginPageTitle = driver.getTitle();
		assertEquals(Title, LoginPageTitle);
	}

	/*
	 * After Login Checking Balance of the DTH account
	 */
	@Test(priority = 1)
	public void TC_02() {
		driver.findElement(By.xpath("//span[contains(text(),\"Account\")]")).click();
		driver.findElement(By.xpath("//a[@id=\"subidRadioButtonID\"]")).click();// sendKeys("1274092434");
		driver.findElement(By.xpath("//input[@id=\"_58_loginSubIdRMN\"]")).sendKeys("1274092434");
		driver.findElement(By.xpath("//button[@id=\"submitbtn\"]")).click();
		driver.findElements(By.xpath("//div[@class=\"coloumsModalRowColor\"]/div/div/a"));
		WebElement bal = driver
				.findElement(By.xpath("//div[@class=\"col-md-2 col-sm-6 col-xs-6\"]/div/span/p[@id=\"remove_span\"]"));
		System.out.println("Avaialble Balaance is:" + bal.getText());
		Assert.assertEquals(bal, bal);
	}

	// 1274092434
	// 1232716884
	/*
	 * Manage Packs
	 */
	@Test(priority = 2)
	public void TC_03() {
		//// p[contains(text(),"not")]
		driver.findElement(By.xpath("//li/a[text()=\"Manage Packs\"]")).click();
		WebElement status = driver.findElement(By.xpath("//p[contains(text(),\"not\")]"));
		System.out.println(status.getText());
		if (status.getText().contains("not Active")) {
			System.out.println("Proceed for recharge");
		} else {
			System.out.println("Manage the packs");
		}
		Assert.assertEquals(Statusofacc, Statusofacc);
	}

	/*
	 * View of Payment mode
	 */
	@Test(priority = 3)
	public void TC_04() {
		driver.findElement(By.xpath("//a[@href=\"https://tsky.in/Recharge/QuickRecharge\"]")).click();
		driver.findElement(By.id("subscriberId")).sendKeys("1274092434");
		driver.findElement(By.id("amount")).sendKeys("310");
		driver.findElement(By.id("submitRecharge")).click();
		List<WebElement> Paymentmode = driver
				.findElements(By.xpath("//div[@class=\"list-group tabs-scroll col-sm-12\"]/a"));
		System.out.println("Modes Of Payment:");
		for (WebElement list : Paymentmode) {
			System.out.println(list.getText());
		}
		int count = Paymentmode.size();
		assertEquals(count, total);

	}

	/*
	 * Check whether OTP is generate successfully.
	 */
@Test(priority = 4)
	public void TC_05() throws InterruptedException {
	System.out.println("going to clcik");
		driver.findElement(By.xpath("//input[@value=\"Generate OTP\"]")).click();
		System.out.println("click successfully");
		driver.findElement(By.xpath("//input[@id=\"placeHold\"]")).sendKeys("9921194982");
		driver.findElement(By.xpath("//button[@onclick=\"validateOTP()\"]")).click();
		WebElement OTPgenerated = driver
				.findElement(By.xpath("//div[@id=\"MTL02tab\"]/div/div/label[@class=\"col_4\"]"));
		System.out.println(OTPgenerated.getText());
		assertEquals(OTPgenerated, OTP);
	}
}
