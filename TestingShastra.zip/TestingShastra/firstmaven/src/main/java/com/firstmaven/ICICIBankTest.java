package com.firstmaven;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.gson.annotations.Until;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ICICIBankTest {
	WebDriver driver;
	String parent, PageTitle = "Personal Banking, Online Banking Services - ICICI Bank";

	@BeforeTest
	public void launchbrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.icicibank.com/");
		System.out.println("Browser opened successfully");
		parent = driver.getWindowHandle();
		System.out.println(parent);

	}
/*
 * closing the Popup 
 */
	@Test(groups = {"A"},priority = -1)
	public void closePopup() {
		driver.findElement(By.xpath("//div[@class=\"push-popup desktop-only\"]/div/div[1][text()=\"Later\"]")).click();
		System.out.println("Popup up is closed");
	}
/*
 * Verifying page title
 */
	@Test(dependsOnGroups = {"A"})
	public void TC_01() {
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title, PageTitle);
		// -//a[@class="closeVisit"]
	}
	
	/*
	 * All eleven product names shouls be display
	 */
	@Test
	public void TC_02() {
		driver.findElement(By.xpath("//li[@class=\"personal-mobile-1 shorter\"]/a[@rel=\"ct_ctnr\"]")).click();
		List<WebElement> element = driver.findElements(By.xpath("//div[@class=\"cc-card-desc\"]/h4"));
		int count = element.size();
		System.out.println(count);
		for (WebElement elements : element) {
			System.out.println(" " + elements.getText());
		}
		Assert.assertEquals(count, 11);
	}
/*
 * Get Interest Rate for Fixed Deposits for more than one year for senior citizen 
 */
	@Test
	public void TC_03() {
		driver.findElement(By.xpath("//a[@id=\"fd\"]/div[contains(text(),\"Fixed Deposit\")]")).click();
		FluentWait wait1 = new FluentWait(driver);
		wait1.withTimeout(10000, TimeUnit.MILLISECONDS);
		wait1.pollingEvery(10000, TimeUnit.MILLISECONDS);
		wait1.ignoring(ElementNotInteractableException.class);
		wait1.withMessage("Element is not Clickable at this moment");
		wait1.until(ExpectedConditions.elementToBeClickable(
				By.xpath("//ul[@class=\"product-sublinks on\"]/li[3]/a[text()=\"Interest Rates\"]")));

		System.out.println("element is click or not");
		driver.findElement(By.xpath("//ul[@class=\"product-sublinks on\"]/li[3]/a[text()=\"Interest Rates\"]")).click();

		FluentWait wait = new FluentWait(driver);
		wait.withTimeout(10000, TimeUnit.MILLISECONDS);
		wait.pollingEvery(10000, TimeUnit.MILLISECONDS);
		wait.ignoring(ElementNotInteractableException.class);
		wait.withMessage("Element is not Clickable at this moment");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//div[@class=\"answers-article accordian clearfix close\"][2]/h2/span[contains(text(),\"with\")]")));
		driver.findElement(By.xpath(
				"//div[@class=\"answers-article accordian clearfix close\"][2]/h2/span[contains(text(),\"with\")]"))
				.click();
		WebElement rate = driver
				.findElement(By.xpath("//div[@class=\"table-container whiteBg\"]/table/tbody/tr[10]/td[3]"));
		System.out.println("Intrest Rate for senior citizen for more than one year:" + rate.getText());
		Assert.assertEquals(rate, rate);

	}
/*
 * Display Loan Offers for
 */
	@Test
	public void TC_04() throws InterruptedException {
		Thread.sleep(5000);
		driver.navigate().back();
		driver.navigate().back();
		driver.findElement(By.xpath("//div[@class=\"thumb-banner loans\"]/div[2]/div[contains(text(),\"APPLY\")]"))
				.click();
		driver.findElement(By.xpath("//div[@id=\"_mod\"]/div[2]/div[1]")).click();
		Thread.sleep(3000);

	}
/*
 * Get all the names of Banking services
 */
	@Test
	public void TC_05() {
		driver.switchTo().window(parent);
		driver.findElement(By.xpath("//div/div[@id=\"_mod\"]/div[@class=\"slvj-close-icon\"]")).click();
		driver.findElement(By.xpath("//a[contains(text(),\"Ways\")]")).click();
		List<WebElement> element = driver.findElements(By.xpath("//div[@class=\"cc-card cc-card-heading\"]/div/h4"));
		for (WebElement elements : element) {
			System.out.println(elements.getText());
		}
		int count = element.size();
		Assert.assertEquals(count, 9);

	}
	/*
	 * Close the Browser
	 */
	@Test
	public void TC_06() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
		System.out.println("driver is closed");

	}
}
